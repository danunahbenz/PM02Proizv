﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompanyManagementCRUD
{
    /// <summary>
    /// Логика взаимодействия для windowRedakt.xaml
    /// </summary>
    public partial class windowRedakt : Window
    {
        private DataTable employeesTable;
        private SqlDataAdapter adapter;
        private SqlConnection connection;
        private SqlCommandBuilder commandBuilder;
        public windowRedakt()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData()
        {
            try
            {
                string connectionString = "Server=DESKTOP-NINUIDH\\SQLEXPRESS;Database=CompanyManagementSystem;Integrated Security=True;";
                string query = "SELECT CompanyID, CompanyName, TaxNumber, RegistrationDate, Website, IsActive FROM Companies";

                connection = new SqlConnection(connectionString);
                adapter = new SqlDataAdapter(query, connection);
                commandBuilder = new SqlCommandBuilder(adapter);

                employeesTable = new DataTable();
                adapter.Fill(employeesTable);

                dataGrid.ItemsSource = employeesTable.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }
        private void EmployeesGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            // Можно добавить валидацию данных перед сохранением
            if (e.Column.Header.ToString() == "Имя")
            {
                var textBox = e.EditingElement as TextBox;
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    e.Cancel = true;
                    MessageBox.Show("Имя не может быть пустым!");
                }
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                adapter.Update(employeesTable);
                MessageBox.Show("Изменения сохранены успешно!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
            }
        }
    }
}
