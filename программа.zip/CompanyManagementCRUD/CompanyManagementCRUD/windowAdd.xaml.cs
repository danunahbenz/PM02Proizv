﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompanyManagementCRUD
{
    /// <summary>
    /// Логика взаимодействия для windowAdd.xaml
    /// </summary>
    public partial class windowAdd : Window
    {
        public windowAdd()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new CompanyManagementSystemEntities())
                {
                    try
                    {
                        var company = new Companies();
                        company.CompanyName = txtName.Text;
                        company.TaxNumber = txtTaxNumber.Text;
                        company.RegistrationDate = Convert.ToDateTime(dpicRegDate.Text);
                        company.Website = txtWeb.Text;
                        if (chkBtn.IsChecked == true)
                        {
                            company.IsActive = true;
                        }
                        else company.IsActive = false;
                        try
                        {
                            db.Companies.Add(company);
                            db.SaveChanges();
                            MessageBox.Show("Вы успешно добавили новую компанию в БД");
                        }
                        catch (Exception ex)
                        { 
                            MessageBox.Show(ex.Message);
                        }   
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            { 
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
